package id.ampro.personalfinance;
import android.content.BroadcastReceiver; import android.content.Context; import android.content.Intent; import android.app.NotificationManager; import android.app.NotificationChannel; import android.app.Notification; import android.os.Build; import android.app.AlarmManager; import android.app.PendingIntent; import java.util.Calendar;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){
  if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); String channel="ampro_daily";
  if(Build.VERSION.SDK_INT>=26){ NotificationChannel ch=new NotificationChannel(channel,"AM PRO Daily Reminder",NotificationManager.IMPORTANCE_DEFAULT); ch.setDescription("Pengingat catatan keuangan harian"); nm.createNotificationChannel(ch); }
  Intent open=new Intent(c,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(c,8103,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("AM PRO · Waktunya mencatat").setContentText("Catat pemasukan dan pengeluaran hari ini, lalu cek saldo & tagihan.").setAutoCancel(true).setContentIntent(pi); nm.notify(8102,b.build());
  android.content.SharedPreferences p=c.getSharedPreferences("ampro_reminder",Context.MODE_PRIVATE); if(!p.getBoolean("enabled",false))return;
  String[] hm=p.getString("time","20:30").split(":"); Calendar cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(hm[0])); cal.set(Calendar.MINUTE,Integer.parseInt(hm[1])); cal.set(Calendar.SECOND,0); cal.add(Calendar.DAY_OF_MONTH,1);
  Intent ri=new Intent(c,ReminderReceiver.class); PendingIntent rpi=PendingIntent.getBroadcast(c,8102,ri,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),rpi);else am.set(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),rpi);
 }
}
