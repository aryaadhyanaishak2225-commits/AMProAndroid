package id.ampro.personalfinance;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.content.Intent;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.Toast;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    web = new WebView(this);
    WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(false);
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new Bridge(this), "AMProAndroid");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
  public static class Bridge {
    Activity a; Bridge(Activity activity){a=activity;}
    @JavascriptInterface public void askNotificationPermission(){ if(Build.VERSION.SDK_INT>=33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100); }
    @JavascriptInterface public void setDailyReminder(boolean enabled, String time){
      if(!enabled){ cancel(); return; }
      try { String[] parts=time.split(":"); int hour=Integer.parseInt(parts[0]), minute=Integer.parseInt(parts[1]);
        android.content.SharedPreferences p=a.getSharedPreferences("ampro_reminder",MODE_PRIVATE); p.edit().putBoolean("enabled",true).putString("time",time).apply();
        schedule(hour,minute);
      } catch(Exception e){ Toast.makeText(a,"Waktu pengingat tidak valid",Toast.LENGTH_SHORT).show(); }
    }
    void cancel(){ AlarmManager am=(AlarmManager)a.getSystemService(Context.ALARM_SERVICE); PendingIntent pi=alarmPI(a); am.cancel(pi); a.getSharedPreferences("ampro_reminder",MODE_PRIVATE).edit().putBoolean("enabled",false).apply(); }
    static PendingIntent alarmPI(Context c){ Intent i=new Intent(c,ReminderReceiver.class); return PendingIntent.getBroadcast(c,8102,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); }
    void schedule(int hour,int minute){ AlarmManager am=(AlarmManager)a.getSystemService(Context.ALARM_SERVICE); java.util.Calendar cal=java.util.Calendar.getInstance(); cal.set(java.util.Calendar.HOUR_OF_DAY,hour); cal.set(java.util.Calendar.MINUTE,minute); cal.set(java.util.Calendar.SECOND,0); if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(java.util.Calendar.DATE,1); PendingIntent pi=alarmPI(a); if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); else am.set(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); }
  }
}
