# AM PRO Personal Finance — Android WebView Project

This project wraps the existing AM PRO offline finance app in a native Android WebView shell.

## Requirements
- Android Studio (recent version)
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 (Android Studio will download Gradle/plugin dependencies)

## Build a direct-install APK (no Play Store)
1. Extract this ZIP.
2. Open the `AMProAndroid` folder in Android Studio.
3. Allow Gradle sync and install/download the Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone, open it, and allow **Install unknown apps** for the file manager/browser when Android asks.

## App details
- Package ID: `id.ampro.personalfinance`
- App label: `AM PRO Personal Finance`
- Offline HTML asset: `app/src/main/assets/index.html`
- Data remains in WebView local storage on this device.
- Daily reminder bridge schedules Android notifications. Permission is requested when enabling the reminder.

This is a source project, not a precompiled APK. The current build environment does not contain Android SDK/Gradle, so APK compilation cannot be completed here. Build it using Android Studio as above.
