# AM PRO Personal Finance — Android

Android WebView wrapper for the AM PRO personal finance app. This project is prepared to build a debug APK using GitHub Actions (cloud), so you do not need Android Studio on your phone.


## Build APK using only an Android phone

1. Create/sign in to a GitHub account at https://github.com.
2. Create a **public** repository named `AMProAndroid` (public is easiest for this workflow).
3. On the repository page, use **Add file → Upload files** and upload the contents of this project folder. Make sure `.github/workflows/build-apk.yml` is included. If GitHub mobile hides dot-folders, switch your browser to Desktop site.
4. Commit the upload to the `main` branch.
5. Open the repo's **Actions** tab, choose **Build AM PRO APK**, and tap **Run workflow** if it has not started automatically.
6. Wait for the workflow to finish with a green checkmark.
7. Open the completed run, scroll to **Artifacts**, and download `AM-PRO-APK`.
8. Extract the artifact ZIP. Open `app-debug.apk` and install. If Android prompts, allow installation from this browser/files app.


## Notes
- This is a debug APK for personal sideloading, not Play Store release signing.
- Do not store your finance backup files in a public repository. The repository contains app source, not your runtime finance data.
- The cloud build artifact is retained for 14 days.
